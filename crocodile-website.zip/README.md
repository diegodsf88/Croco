# Crocodile Website

Simple crocodile-themed website.

## Features
- Nature-inspired design
- Interactive fact button
- Beginner-friendly structure

## How to Use
Open index.html in your browser.
