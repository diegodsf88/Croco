function showFact() {
  const facts = [
    "Crocodiles can live over 70 years.",
    "They have one of the strongest bite forces in the animal kingdom.",
    "Crocodiles can hold their breath underwater for over an hour."
  ];
  const randomFact = facts[Math.floor(Math.random() * facts.length)];
  alert(randomFact);
}
